import random
import discord
import requests

Intents = discord.Intents.all()
client = discord.Client(intents=Intents)

# A dictionary to keep track of which user is assigned to which player position
players = {}

@client.event
async def on_ready():
    print('Logged in as {0.user}'.format(client))


# ------------------------------------ bird fact zone -----------------------------------
def bird_fact():
  # basically tells you a fact about birds 
  response = requests.get("https://www.birdfactz.com/random-fact")
  fact = response.json("fact")
  return fact # birdfact request 

#def birdfact_cmd(msg):
 ##fact = bird_fact()
 # msg.channel.send(fact) #birdfact command's function 

@client.event
async def on_msg(msg): 
  # execute the given command
  if msg.content.startswith("!birdfact"):
    await msg.channel.send(birdfact_cmd())


@client.event
async def bird_cmd(message):
  response = requests.get("https://www.birdfactz.com/random-fact")
  fact = response.json("fact")
  #return fact # birdfact request 
  if message.content.startswith("!birdfact"):
    await message.channel.send(bird_fact())
    
#--------------------------------------- Game code -----------------------------------

@client.event
async def on_message(message):
    global players, game_over

    if message.author == client.user:
        return

    if message.content.startswith('!register'):
        # Assign player positions based on the order in which players register
        if len(players) == 0:
            players[message.author] = 1
            await message.channel.send(f"{message.author.mention} is now player one.")
        elif len(players) == 1:
            players[message.author] = 2
            await message.channel.send(f"{message.author.mention} is now player two.")
        else:
            await message.channel.send("Sorry, this game is limited to two players.")

    if message.content.startswith('!roll'):
        if len(players) < 2:
            await message.channel.send("Sorry, there are not enough players to start the game.")
            return

        # Determine which player is currently playing based on the order in which they registered
        player_number = players[message.author]

        await message.channel.send(f"Player {player_number}, press any key to roll the dice...")
        def check(msg):
            return msg.author == message.author and msg.channel == message.channel
        await client.wait_for("message", check=check)

        player_roll = roll_dice(player_number)
        computer_roll = roll_dice(3 - player_number)
        await message.channel.send(f"Player {player_number}, you rolled a {player_roll}. The computer rolled a {computer_roll}.")

        if player_roll > computer_roll:
            await message.channel.send(f"Player {player_number} won the round!")
            scores[player_number].append(1)
        elif computer_roll > player_roll:
            await message.channel.send(f"The computer won the round!")
            scores[3 - player_number].append(1)
        else:
            await message.channel.send("It's a tie!")

        if len(players) == 2:
            # Check if the game is over
            if len(players) == 2 and len(players.values()) == len(set(players.values())):
                # If both players have won 3 rounds, end the game
                if len(scores[1]) == 5 or len(scores[2]) == 5:
                    await message.channel.send("Game over!")
                    score_one = sum(scores[1])
                    score_two = sum(scores[2])
                    if score_one > score_two:
                        await message.channel.send(f"Player one won the game with a score of {score_one}!")
                    elif score_two > score_one:
                        await message.channel.send(f"Player two won the game with a score of {score_two}!")
                    else:
                        await message.channel.send("It's a tie game!")
                else:
                    # If the game is not over, continue to the next round
                    await message.channel.send("Next round!")
            else:
                await message.channel.send("Please register both players before starting the game.")

    if message.content.startswith('!players'):
        if len(players) == 0:
            await message.channel.send("No players have registered yet.")
        else:
            player_list = [str(player) for player in sorted(players.keys())]
            message_content = "Players:\n" + "\n".join(player_list)
            await message.channel.send(message_content)

    if message.content.startswith('!help'):
      await message.channel.send(f"{message.author.mention}, your list of commands has been sent in your Dm's.")
      author = message.author
      help_message = "The commands are as follows: \n```!help```  This command shows you every command you need \n ```!register```This command helps you take a spot as player one or two \n ```!players``` This displays a detailed message of every player in the game \n ```!roll``` just make sure you press this and then when Zeldrice replies you do what it says"
      await author.send(help_message)

    if message.content.startswith('!stop'):
        if message.author in players:
            game_over = True
            await message.channel.send("The game has been stopped.")
        else:
            await message.channel.send("Sorry, you are not a player in the game.")
        

# A dictionary to keep track of player scores
scores = {1: [], 2: []}

def roll_dice(player_number):
    return random.randint(1, 6)

client.run('MTAxMjQ2MDkwOTQwODU2NzM4OA.GjQGw1.0QBm_zbdfpZS2yyAiIttCNTqC-dBMVLOyDJgIs')